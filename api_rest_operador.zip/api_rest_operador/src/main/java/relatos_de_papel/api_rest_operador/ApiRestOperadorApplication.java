package relatos_de_papel.api_rest_operador;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiRestOperadorApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiRestOperadorApplication.class, args);
	}
}