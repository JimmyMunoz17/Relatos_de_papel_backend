package relatos_de_papel.api_rest_operador;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiRestOperadorApplicationTests {

	@Test
	void contextLoads() {
	}

}