package relatos_de_papel.api_rest_buscador;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiRestBuscadorApplicationTests {

	@Test
	void contextLoads() {
	}

}
