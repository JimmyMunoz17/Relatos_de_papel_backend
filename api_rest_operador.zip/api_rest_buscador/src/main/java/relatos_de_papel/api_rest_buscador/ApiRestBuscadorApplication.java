package relatos_de_papel.api_rest_buscador;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiRestBuscadorApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiRestBuscadorApplication.class, args);
	}

}
