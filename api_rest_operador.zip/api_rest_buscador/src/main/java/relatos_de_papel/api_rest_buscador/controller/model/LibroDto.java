package relatos_de_papel.api_rest_buscador.controller.model;

import lombok.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@ToString
public class LibroDto {
    private Long id;
    private String titulo;
    private String autor;
    private String fecha_publicacion;
    private String categoria;
    private String isbn;
    private Integer valoracion;
    private Boolean visibilidad;
    private Integer stock;

    public LibroDto(Long id, Boolean visibilidad, Integer valoracion, String isbn, String categoria, String fecha_publicacion, String autor, String titulo, Integer stock) {
        this.id = id;
        this.visibilidad = visibilidad;
        this.valoracion = valoracion;
        this.isbn = isbn;
        this.categoria = categoria;
        this.fecha_publicacion = fecha_publicacion;
        this.autor = autor;
        this.titulo = titulo;
        this.stock = stock;
    }

    public String getTitulo() {
        return titulo;
    }

    public Boolean getVisibilidad() {
        return visibilidad;
    }

    public Integer getValoracion() {
        return valoracion;
    }

    public String getIsbn() {
        return isbn;
    }

    public String getFecha_publicacion() {
        return fecha_publicacion;
    }

    public String getAutor() {
        return autor;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public void setVisibilidad(Boolean visibilidad) {
        this.visibilidad = visibilidad;
    }

    public void setValoracion(Integer valoracion) {
        this.valoracion = valoracion;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public void setFecha_publicacion(String fecha_publicacion) {
        this.fecha_publicacion = fecha_publicacion;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }
    
    public Long getId() {
        return id;
    }
    
    public void setId(Long id) {
        this.id = id;
    }
    
    public Integer getStock() {
        return stock;
    }
    
    public void setStock(Integer stock) {
        this.stock = stock;
    }
}
